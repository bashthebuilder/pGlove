CORPUS=/home/msjameel/acl_2016/text_collections/wikipedia_entities_hyphenated.txt
VOCAB_FILE=vocab.txt
COOCCURRENCE_FILE=cooccurrence.bin
COOCCURRENCE_SHUF_FILE=cooccurrence.shuf.bin
BUILDDIR=build
SAVE_FILE=vectors
VERBOSE=2
MEMORY=4.0
VOCAB_MIN_COUNT=10
WINDOW_SIZE=10
BINARY=2
NUM_THREADS=12
X_MAX=100

$BUILDDIR/vocab_count -min-count $VOCAB_MIN_COUNT -verbose $VERBOSE < $CORPUS > $VOCAB_FILE
$BUILDDIR/cooccur -memory $MEMORY -vocab-file $VOCAB_FILE -verbose $VERBOSE -window-size $WINDOW_SIZE < $CORPUS > $COOCCURRENCE_FILE
$BUILDDIR/shuffle -memory $MEMORY -verbose $VERBOSE < $COOCCURRENCE_FILE > $COOCCURRENCE_SHUF_FILE

for VECTOR_SIZE in {50..500..50}
do
  for MAX_ITER in {10..150..20}
  do
    START=$(date +%s)
    $BUILDDIR/glove -save-file $SAVE_FILE_$MAX_ITER_$VECTOR_SIZE -threads $NUM_THREADS -input-file $COOCCURRENCE_SHUF_FILE -x-max $X_MAX -iter $MAX_ITER -vector-size $VECTOR_SIZE -binary $BINARY -vocab-file $VOCAB_FILE -verbose $VERBOSE
    END=$(date +%s)
    DIFF=$(( $END - $START ))
    echo "It took $DIFF seconds" > $MAX_ITER_$VECTOR_SIZE.time
    python eval/python/evaluate.py --vectors_file $SAVE_FILE_$MAX_ITER_$VECTOR_SIZE > $SAVE_FILE_$MAX_ITER_$VECTOR_SIZE.output
    done
done
